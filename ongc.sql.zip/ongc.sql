-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 27, 2024 at 11:41 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ongc`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_rules`
--

CREATE TABLE `add_rules` (
  `id` int(5) NOT NULL,
  `category` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `add_rules`
--

INSERT INTO `add_rules` (`id`, `category`) VALUES
(1, 'RULES! <br>                  1.Each Quiz consists of minimum 10 questions. <br>                  2.Each Question has to be answered. <br>                  3.There are no negative marking for any wrong answer. <br>');

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `id` int(5) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`id`, `username`, `password`) VALUES
(0, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `exam_category`
--

CREATE TABLE `exam_category` (
  `id` int(5) NOT NULL,
  `category` varchar(100) NOT NULL,
  `exam_time_in_minutes` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `exam_category`
--

INSERT INTO `exam_category` (`id`, `category`, `exam_time_in_minutes`) VALUES
(2, 'Simple Maths', '2'),
(18, 'General Knowledge', '2'),
(19, 'Science', '2');

-- --------------------------------------------------------

--
-- Table structure for table `exam_results`
--

CREATE TABLE `exam_results` (
  `id` int(5) NOT NULL,
  `username` varchar(100) NOT NULL,
  `exam_type` varchar(100) NOT NULL,
  `total_question` varchar(10) NOT NULL,
  `correct_answer` varchar(10) NOT NULL,
  `wrong_answer` varchar(10) NOT NULL,
  `exam_time` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `exam_results`
--

INSERT INTO `exam_results` (`id`, `username`, `exam_type`, `total_question`, `correct_answer`, `wrong_answer`, `exam_time`) VALUES
(4, 'anurag', 'Simple Maths', '4', '0', '4', '2024-06-19'),
(5, 'anurag', 'Simple Maths', '4', '0', '4', '2024-06-21'),
(6, 'anurag', 'PHP', '3', '0', '3', '2024-06-21'),
(7, 'anurag', 'PHP', '3', '0', '3', '2024-06-21'),
(8, 'anurag', 'General Knowledge', '5', '5', '0', '2024-06-21'),
(9, 'ABHAY_1215', 'General Knowledge', '6', '6', '0', '2024-06-21'),
(10, 'ABHAY_1215', 'General Knowledge', '6', '0', '6', '2024-06-21'),
(11, 'anurag', 'Simple Maths', '4', '0', '4', '2024-06-21'),
(12, 'anurag', 'Simple Maths', '4', '1', '3', '2024-06-21'),
(13, 'anurag', 'Simple Maths', '4', '1', '3', '2024-06-21'),
(17, 'anurag', 'Simple Maths', '4', '0', '4', '2024-06-21'),
(18, 'anurag', 'Simple Maths', '4', '0', '4', '2024-06-21'),
(19, 'anurag', 'Simple Maths', '4', '0', '4', '2024-06-21'),
(20, 'ABHAY_1215', 'Simple Maths', '4', '1', '3', '2024-06-21'),
(26, 'ABHAY_1215', 'Simple Maths', '4', '2', '2', '2024-06-21'),
(27, 'ABHAY_1215', 'Simple Maths', '4', '2', '2', '2024-06-23'),
(28, 'anurag', 'Simple Maths', '4', '2', '2', '2024-06-23'),
(29, 'anurag', 'Simple Maths', '4', '1', '3', '2024-06-23'),
(30, 'anurag', 'Simple Maths', '4', '2', '2', '2024-06-23'),
(31, 'anurag', 'Simple Maths', '4', '1', '3', '2024-06-23'),
(32, 'anurag', 'Simple Maths', '4', '2', '2', '2024-06-23'),
(33, 'anurag', 'Simple Maths', '4', '2', '2', '2024-06-23'),
(34, 'anurag', 'Simple Maths', '4', '2', '2', '2024-06-23'),
(35, 'anurag', 'PHP', '3', '0', '3', '2024-06-23'),
(37, 'anurag', 'Simple Maths', '4', '2', '2', '2024-06-23'),
(38, 'anurag', 'Simple Maths', '4', '0', '4', '2024-06-25'),
(39, 'anurag', 'Simple Maths', '4', '3', '1', '2024-06-25'),
(40, 'anurag', 'Simple Maths', '4', '2', '2', '2024-06-25'),
(41, 'ABHAY_1215', 'General Knowledge', '7', '0', '7', '2024-06-26'),
(42, 'ABHAY_1215', 'Simple Maths', '5', '0', '5', '2024-06-26');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(5) NOT NULL,
  `question_no` varchar(5) NOT NULL,
  `question` varchar(500) NOT NULL,
  `opt1` varchar(100) NOT NULL,
  `opt2` varchar(100) NOT NULL,
  `opt3` varchar(100) NOT NULL,
  `opt4` varchar(100) NOT NULL,
  `answer` varchar(100) NOT NULL,
  `category` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `question_no`, `question`, `opt1`, `opt2`, `opt3`, `opt4`, `answer`, `category`) VALUES
(2, '2', '13+27=?', '10', '20', '30', '40', '40', 'PHP'),
(10, '3', '99+22=?', '121', '141', '131', '111', '121', 'PHP'),
(12, '4', 'Which one among these is the very first alphabet?', 'opt_images/b2740bbaa79e233ca80fe577cf4a2682LetterA.svg.png', 'opt_images/ce5306c41ca913f6ddc0f152424448efB.png', 'opt_images/ce5306c41ca913f6ddc0f152424448efC.png', 'opt_images/ce5306c41ca913f6ddc0f152424448efD.png', 'opt_images/0e7db31dfc19758d1fd48ef586c0a582B.png', 'PHP'),
(13, '1', '|-20|=?', '-20', '-(-(-20))', '+20', '-(+20)', '20', 'Simple Maths'),
(15, '2', 'which is the Smallest whole number?', '1', '4', '0', '2', '0', 'Simple Maths'),
(16, '3', 'which is greater than 4?', '5', '4', '2', '1', '5', 'Simple Maths'),
(17, '4', 'what is square of 2?', '2', '5', '3', '4', '4', 'Simple Maths'),
(18, '1', 'What is the Capital of India?', 'New Delhi', 'Mumbai', 'Bangalore', 'Hyderabad', 'New Delhi', 'General Knowledge'),
(19, '2', 'Which is the Financial Capital of India?', 'New Delhi', 'Mumbai', 'Bangalore', 'Hyderabad', 'Mumbai', 'General Knowledge'),
(20, '3', 'What is the current inflation rate in India?', '5.4', '7.6', '3.8', '6.2', '5.4', 'General Knowledge'),
(21, '4', 'Which is the hottest planet in the solar system?', 'Mercury', 'Venus', 'Neptune', 'Jupiter', 'Venus', 'General Knowledge'),
(22, '5', 'What is the name of the most popular sport in the world?', 'Badminton', 'Cricket', 'Golf', 'Soccer', 'Soccer', 'General Knowledge'),
(23, '6', 'What is the current unemployment rate in India?', '9.2%', '7.8%', '4.6%', '8.2%', '7.8%', 'General Knowledge'),
(25, '1', 'Which animal never drinks water in its entire life?', 'kangaroo', 'hippopotamus', 'rat', 'kangaroo rat', 'kangaroo rat', 'Science'),
(26, '2', 'what is the physical phase of life called?', 'protoplasm', 'cytoplasm', 'organelles', 'none of the above', 'protoplasm', 'Science'),
(27, '3', 'The largest cell is ?', 'Nerve cell', 'ovum', 'The egg of an Ostrich', 'None of the above', 'The egg of an Ostrich', 'Science'),
(28, '4', 'Which is the largest human cell?', 'Liver', 'Skin', 'Spleen', 'Ovum', 'Ovum', 'Science'),
(29, '5', 'There are ______ number of muscles in human.', '638', '637', '639', '640', '639', 'Science'),
(30, '6', 'What is the life span of RBC?', '130 days', '110 days', '100 days', '120 days', '120 days', 'Science'),
(31, '7', 'What is the life span of WBC?', '2-15 days', '3-15 days', '4-15 days', '5-20 days', '2-15 days', 'Science'),
(32, '8', 'Which is the vertebrate that has two chambered heart?', 'Fish', 'Snake', 'Blue Whale', 'Crocodile', 'Fish', 'Science'),
(33, '9', 'The number of Ribs in human body is ______. ', '23', '24', '25', '22', '24', 'Science'),
(34, '10', 'Which is the smallest flightless bird?', 'Kiwi', 'Penguin', 'Ostrich', 'Rhea', 'Kiwi', 'Science'),
(35, '5', 'How many years are there in a decade?', '5 years', '10 years', '15 years', '20 years', '10 years', 'Simple Maths');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(5) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `firstname`, `lastname`, `username`, `password`, `email`, `contact`) VALUES
(1, 'Anurag', 'Das', 'anurag', 'anurag123', 'anuragdas636@gmail.com', '8451943741'),
(4, 'Abhay', 'Singh', 'Abhay_1215', 'abhay1215', 'abhay@1215', '1234567891');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_rules`
--
ALTER TABLE `add_rules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exam_category`
--
ALTER TABLE `exam_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exam_results`
--
ALTER TABLE `exam_results`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_rules`
--
ALTER TABLE `add_rules`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `exam_category`
--
ALTER TABLE `exam_category`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `exam_results`
--
ALTER TABLE `exam_results`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
