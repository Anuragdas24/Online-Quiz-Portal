
<?php
session_start();
if (!isset($_SESSION["username"])) {
?>
    <script type="text/javascript">
        window.location = "login.php";
    </script>
<?php
}
?>

<?php
include "connection.php";
include "header.php";
?>

<div class="row" style="margin: 0px; padding:0px; margin-bottom: 50px;">
    <div class="col-lg-6 col-lg-push-3" style="min-height: 400px; background-color: white; display: flex; justify-content: center; align-items: center; flex-direction: column;">
        <div class="rules-container" style="width: 550px; background-color: black; color: white; padding: 20px; text-align: left;">
            
            <?php
            $res = mysqli_query($link, "SELECT * FROM add_rules");
            while ($row = mysqli_fetch_array($res)) {
                echo "<p style='white-space: pre-wrap; line-height: 1.5rem;'>" . $row["category"] . "</p>";
            }
            ?>
        </div>
        <div class="exam-buttons" style="width: 550px; margin-top: 20px;">
            <?php
            $res = mysqli_query($link, "SELECT * FROM exam_category");
            while ($row = mysqli_fetch_array($res)) {
            ?>
                <input type="button" class="btn btn-success form-control" value="<?php echo $row["category"]; ?>" style="margin-top: 10px; background-color: blue; color: white; text-align: center;" onclick="set_exam_type_session(this.value);">
            <?php
            }
            ?>
        </div>
    </div>
</div>

<?php
include "footer.php";
?>

<script type="text/javascript">
    function set_exam_type_session(exam_category) {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                alert(xmlhttp.responseText);
                window.location = "dashboard.php";
            }
        };
        xmlhttp.open("GET", "forajax/set_exam_type_session.php?exam_category=" + exam_category, true);
        xmlhttp.send(null);
    }
</script>