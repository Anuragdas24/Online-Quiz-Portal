<?php

include "../connection.php";

$id=$_GET["id"];
mysqli_query($link,"delete from add_rules where id=$id");
?>

<script type="text/javascript">
    window.location="rules.php";
</script>